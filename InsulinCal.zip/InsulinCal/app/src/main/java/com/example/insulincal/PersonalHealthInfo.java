package com.example.insulincal;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class PersonalHealthInfo extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.personalhealth_activity);
    }
}

